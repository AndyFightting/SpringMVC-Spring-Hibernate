INSERT INTO DateEvent ( timestamp, id )
VALUES ( '2015-12-29', 1 )