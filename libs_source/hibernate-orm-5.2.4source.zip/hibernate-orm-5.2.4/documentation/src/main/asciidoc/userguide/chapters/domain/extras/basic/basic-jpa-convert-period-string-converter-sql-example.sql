INSERT INTO Event ( span, id )
VALUES ( 'P1Y2M3D', 1 )