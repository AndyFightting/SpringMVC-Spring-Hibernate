@Entity
public class MyEntity {

    @Id
    @GeneratedValue
    public Integer id;

    ...
}