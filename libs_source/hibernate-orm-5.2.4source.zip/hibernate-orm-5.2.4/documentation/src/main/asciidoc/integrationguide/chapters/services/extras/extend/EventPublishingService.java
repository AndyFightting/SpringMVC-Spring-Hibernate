public interface EventPublishingService extends Service {

    public void publish(Event theEvent);
}